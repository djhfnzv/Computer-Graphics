#include<bits/stdc++.h>
#include <cmath>
using namespace std;
#include<windows.h> // for MS Windows
#include<GL/glut.h> // glut,include glu.h and gl.h


int arr[100][100]={0};

struct point{
    int x,y;
};

point start,ending;

void display(){
    glClearColor(1.0f,1.0f,1.0f,1.0f); // BG set to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // clear color buffer (background)

    glLineWidth(2);
    glBegin(GL_LINES);

    glColor3ub(207,91,14); // axis
    glVertex2f(-1.0f,1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();
    glBegin(GL_LINES);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(-1.0f,-1.0f);
    glEnd();

    glColor3ub(0,0,0);
    glPointSize(6);
    glBegin(GL_POINTS );
        for(int i=0;i<100;i++){
            for(int j=0;j<100;j++){
                if(arr[i][j] == 1){
                    float gx=(i / 50.0f)-1.0f;
                    float gy=(j / 50.0f)-1.0f;
                    glVertex2f(gx,gy);
                }
            }
        }
    glEnd();


    glFlush(); // render
}

int inputPoints(){

    cout<<"\nEnter the starting points"<<endl;
    cout<<"x1 :"; cin>>start.x;
    cout<<"y1 :"; cin>>start.y;


    cout<<"\nEnter the ending points"<<endl;
    cout<<"x2 :"; cin>>ending.x;
    cout<<"y2 :"; cin>>ending.y;
    cout<<endl;

}

int inputPointsMPC(){
    cout<<"\nEnter the starting points"<<endl;
    cout<<"x1 :"; cin>>start.x;
    cout<<"y1 :"; cin>>start.y;


    cout<<"\nRadius"<<endl;
    cout<<"x2 :"; cin>>ending.x;
    cout<<endl;
}

void clearArr(){
    for(int i=0;i<100;i++){
        for(int j=0;j<100;j++){
            arr[i][j]=0;
        }
    }
}

void print(){
    for(int i=0;i<100;i++){
        for(int j=0;j<100;j++){
            if(arr[i][j]==1){
                cout<<"Plot : "<<"("<<i<<","<<j<<")"<<endl;
            }
        }
    }
}

int dda(){

    // clear arr
    clearArr();

    double x1=start.x;
    double y1=start.y;
    double x2=ending.x;
    double y2=ending.y;

    double dy=y2-y1;
    double dx=x2-x1;

    arr[(int)x1][(int)y1]=1;
    arr[(int)x2][(int)y2]=1;

    // fix slope
    double m=dy / dx;

    // horizontal
    if(dy == 0){
        if(x1>x2){
            swap(x1,x2);
        }
        for(int i=x1;i<=x2;i++){
            arr[i][(int)y1]=1;
        }
        print();
    }

    // vertical
    else if(dx == 0){
        if(y1>y2){
            swap(y1,y2);
        }
        for(int j=y1;j<=y2;j++){
            arr[(int)x1][j]=1;
        }
        print();
    }

    // m == 1
    else if(m == 1){
        if(x1>x2){
            swap(x1,x2);
            swap(y1,y2);
        }

        for(int i=x1,j=y1; i<=x2; i++,j++){
            arr[i][j]=1;
        }
        print();
    }

    // |m|<1
    else if(fabs(m)<1){

        if(x1>x2){
            swap(x1,x2);
            swap(y1,y2);
        }

        while(x1<=x2){
            int yy=round(y1);
            arr[(int)x1][yy]=1;

            x1 += 1;
            y1+=m;
        }
        print();
    }

    // |m|>1
    if(y1>y2){
        swap(x1,x2);
        swap(y1,y2);
    }

    while(y1<=y2){
        int xx=round(x1);
        arr[xx][(int)y1]=1;

        y1+=1;
        x1+=(1.0 / m);
    }
    print();
}

int midPointLine(){

    // clear array
    clearArr();


    int x1=start.x;
    int y1=start.y;
    int x2=ending.x;
    int y2=ending.y;

    //left -> right drawing
    if(x1>x2){
        swap(x1,x2);
        swap(y1,y2);
    }

    int dx=x2-x1;
    int dy=y2-y1;

    int d=(2*dy)-dx;        // dstart
    int dE =2*dy;             // E
    int dNE=2*(dy-dx);      // NE

    int x=x1;
    int y=y1;

    arr[x][y]=1;

    while(x<x2){
        if(d<0){
            // choose E
            d+=dE;
            x++;
        }
        else{
            // choose NE
            d+=dNE;
            x++;
            y++;
        }
        arr[x][y]=1;
    }
    print();
}

void plotCirclePoints(int xc,int yc,int x,int y){
    arr[xc+x][yc+y]=1;
    arr[xc-x][yc+y]=1;
    arr[xc+x][yc-y]=1;
    arr[xc-x][yc-y]=1;
    arr[xc+y][yc+x]=1;
    arr[xc-y][yc+x]=1;
    arr[xc+y][yc-x]=1;
    arr[xc-y][yc-x]=1;
}

int midPointCircle(){

    clearArr();

    int xc=start.x;
    int yc=start.y;
    int R =ending.x;

    int xp=0;
    int yp=R;

    int d=1-R;     // dstart

    plotCirclePoints(xc,yc,xp,yp);

    while(xp<yp){

        if(d<0){
            // E move
            d=d+(2*xp+3);
            xp=xp+1;
        }
        else{
            // SE move
            d=d+(2*xp-2*yp+5);
            xp=xp+1;
            yp=yp-1;
        }

        plotCirclePoints(xc,yc,xp,yp);
    }

    print();
}


int main(int argc ,char** argv){


    cout<<"Select an option From below :"<<endl;
    cout<<"1. DDA LINE          : Enter '1'"<<endl;
    cout<<"2. MID POINT LINE    : Enter '2'"<<endl;
    cout<<"3. MID POINT CIRCLE  : Enter '3'"<<endl;
    cout<<" Exit                : Enter '0'"<<endl;

    int choice;
    cout<<"Choose (A-C):";
    cin>>choice;

    switch(choice){
    case 1:
        inputPoints();
        dda();
        break;
    case 2:
        inputPoints();
        midPointLine();
        break;
    case 3:
        inputPointsMPC();
        midPointCircle();
        break;
    case 0:
        return 0;
        break;
    default:
        cout<<"\nInvalid Choice\n"<<endl;
    }


    glutInit(&argc,argv);
    glutInitWindowSize(640,480); // set window's initial size
    glutInitWindowPosition(80,50); // set position
    glutCreateWindow("OpenGL Setup Test"); // window title
    glutDisplayFunc(display); // register display callback handler for window re-paint

    glutMainLoop();// enter the event-processing loop
    return 0;

}
